from tools.config import paths
from tools.config.upgrade import UpgradeConfig
from tools.resource import upgrade_service


def main() -> None:
    upgrade_service.upgrade_ark_pixel()

    upgrade_configs = UpgradeConfig.load()
    for upgrade_config in upgrade_configs:
        upgrade_service.upgrade_fonts(upgrade_config)

    for file_path in paths.FONTS_DIR.rglob('*.txt'):
        if not file_path.is_file():
            continue

        text = file_path.read_text('utf-8')
        file_path.write_text(text, 'utf-8')


if __name__ == '__main__':
    main()
