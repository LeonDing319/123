from tools.extra import publish_service


def main() -> None:
    publish_service.update_docs()


if __name__ == '__main__':
    main()
