import math
from collections.abc import Mapping, Sequence
from datetime import datetime

from loguru import logger
from pixel_font_builder import FontBuilder, Weight, SerifStyle, Spacing, Slant, Glyph, MonoRaster, opentype
from pixel_font_knife.cmap.context import CmapContext
from pixel_font_knife.cmap.kerning.template import CmapKerningTemplate
from pixel_font_knife.cmap.mapping.mapping import CmapMapping
from pixel_font_knife.named.context import NamedContext
from pixel_font_knife.named.file import NamedGlyphFile

from tools.config import paths, project, manifest, options
from tools.config.font import FontConfig
from tools.config.glyph.metric import MetricGlobalRules, MetricSizeRules
from tools.config.options import WidthMode, LanguageFlavor, FontFormat


class FontBuildContext:
    @staticmethod
    def load(
            font_config: FontConfig,
            scope_mappings: Mapping[str, Sequence[CmapMapping]],
            metric_global_rules: MetricGlobalRules,
            metric_size_rules: MetricSizeRules,
            kerning_template: CmapKerningTemplate,
    ) -> FontBuildContext:
        font_size = font_config.font_size

        notdef_glyph_file = NamedGlyphFile.load_notdef(paths.PATCH_GLYPHS_DIR.joinpath(str(font_size), 'notdef.png'))

        cmap_scope_contexts = {
            glyph_scope: CmapContext().merge_by_code_point(
                CmapContext.load(
                    paths.FALLBACK_GLYPHS_DIR.joinpath(str(font_size), 'cmap', glyph_scope),
                    allowed_flavors=options.LANGUAGE_FLAVORS,
                ).with_default_flavor(options.LANGUAGE_FLAVORS),
                CmapContext.load(
                    paths.ARK_PIXEL_GLYPHS_DIR.joinpath(str(font_size), 'cmap', glyph_scope),
                    allowed_flavors=options.LANGUAGE_FLAVORS,
                ),
                CmapContext.load(
                    paths.PATCH_GLYPHS_DIR.joinpath(str(font_size), 'cmap', glyph_scope),
                    allowed_flavors=options.LANGUAGE_FLAVORS,
                ),
                conflict='replace',
            ).apply_mapping_by_flavor(
                *(scope_mappings['common'] if glyph_scope == 'common' else scope_mappings['other']),
                conflict='replace',
            )
            for glyph_scope in options.GLYPH_SCOPES
        }

        cmap_contexts = {
            width_mode: CmapContext().merge_by_code_point(
                cmap_scope_contexts['common'],
                cmap_scope_contexts[width_mode],
                conflict='replace',
            )
            for width_mode in options.WIDTH_MODES
        }

        named_scope_contexts = {
            glyph_scope: NamedContext().merge_by_name_key(
                NamedContext.load(
                    paths.ARK_PIXEL_GLYPHS_DIR.joinpath(str(font_size), 'named', glyph_scope),
                    allowed_flavors=options.LANGUAGE_FLAVORS,
                ),
                NamedContext.load(
                    paths.PATCH_GLYPHS_DIR.joinpath(str(font_size), 'named', glyph_scope),
                    allowed_flavors=options.LANGUAGE_FLAVORS,
                ),
                conflict='replace',
            )
            for glyph_scope in options.GLYPH_SCOPES
        }

        named_contexts = {
            width_mode: NamedContext().merge_by_name_key(
                named_scope_contexts['common'],
                named_scope_contexts[width_mode],
                conflict='replace',
            )
            for width_mode in options.WIDTH_MODES
        }

        return FontBuildContext(
            font_config,
            notdef_glyph_file,
            cmap_contexts,
            named_contexts,
            metric_global_rules,
            metric_size_rules,
            kerning_template,
        )

    font_config: FontConfig
    notdef_glyph_file: NamedGlyphFile
    cmap_contexts: dict[WidthMode, CmapContext]
    named_contexts: dict[WidthMode, NamedContext]
    metric_global_rules: MetricGlobalRules
    metric_size_rules: MetricSizeRules
    kerning_template: CmapKerningTemplate

    def __init__(
            self,
            font_config: FontConfig,
            notdef_glyph_file: NamedGlyphFile,
            cmap_contexts: dict[WidthMode, CmapContext],
            named_contexts: dict[WidthMode, NamedContext],
            metric_global_rules: MetricGlobalRules,
            metric_size_rules: MetricSizeRules,
            kerning_template: CmapKerningTemplate,
    ) -> None:
        self.font_config = font_config
        self.notdef_glyph_file = notdef_glyph_file
        self.cmap_contexts = cmap_contexts
        self.named_contexts = named_contexts
        self.metric_global_rules = metric_global_rules
        self.metric_size_rules = metric_size_rules
        self.kerning_template = kerning_template

    @property
    def font_size(self) -> int:
        return self.font_config.font_size

    def get_alphabet(self, width_mode: WidthMode) -> Sequence[str]:
        return [chr(code_point) for code_point in sorted(self.cmap_contexts[width_mode].get_character_mapping().keys())]

    def create_builder(self, width_mode: WidthMode, language_flavor: LanguageFlavor) -> FontBuilder:
        layout_metric = self.font_config.layout_metrics[width_mode]

        builder = FontBuilder()
        builder.font_metric.font_size = self.font_size
        builder.font_metric.horizontal_layout.ascent = layout_metric.ascent
        builder.font_metric.horizontal_layout.descent = layout_metric.descent
        builder.font_metric.vertical_layout.ascent = math.ceil(layout_metric.line_height / 2)
        builder.font_metric.vertical_layout.descent = -math.floor(layout_metric.line_height / 2)
        builder.font_metric.x_height = layout_metric.x_height
        builder.font_metric.cap_height = layout_metric.cap_height
        builder.font_metric.underline_position = layout_metric.underline_position
        builder.font_metric.underline_thickness = 1
        builder.font_metric.strikeout_position = layout_metric.strikeout_position
        builder.font_metric.strikeout_thickness = 1

        builder.meta_info.version = project.VERSION
        builder.meta_info.created_time = datetime.fromisoformat(f'{project.VERSION.replace('.', '-')}T00:00:00Z')
        builder.meta_info.modified_time = builder.meta_info.created_time
        builder.meta_info.family_name = f'{project.FAMILY_NAME_PREFIX} {self.font_size}px {width_mode[:4].capitalize()} {manifest.LANGUAGE_FLAVOR_TO_FONT_NAME[language_flavor]}'
        builder.meta_info.weight = Weight.REGULAR
        builder.meta_info.serif_style = SerifStyle.SANS_SERIF
        builder.meta_info.spacing = Spacing(width_mode.capitalize())
        builder.meta_info.slant = Slant.UPRIGHT
        builder.meta_info.manufacturer = project.MANUFACTURER
        builder.meta_info.designer = project.DESIGNER
        builder.meta_info.description = project.DESCRIPTION
        builder.meta_info.copyright_info = project.COPYRIGHT_INFO
        builder.meta_info.license_info = project.LICENSE_INFO
        builder.meta_info.vendor_url = project.HOMEPAGE_URL
        builder.meta_info.designer_url = project.DESIGNER_URL
        builder.meta_info.license_url = project.LICENSE_URL

        glyph_sequence = [self.notdef_glyph_file] + self.cmap_contexts[width_mode].get_glyph_sequence(language_flavor) + self.named_contexts[width_mode].get_glyph_sequence(language_flavor)
        for glyph_file in glyph_sequence:
            vertical_em_scale = self.metric_global_rules.get_vertical_em_scale(glyph_file)

            advance_width = glyph_file.suggest_advance_width()
            advance_height = glyph_file.suggest_advance_height(self.font_size * vertical_em_scale)

            horizontal_offset_x, horizontal_offset_y = glyph_file.suggest_horizontal_offset(self.font_size, layout_metric.baseline)
            vertical_offset_x, vertical_offset_y = glyph_file.suggest_vertical_offset(self.font_size * vertical_em_scale)
            if not (
                    glyph_file.canvas.is_blank or
                    self.metric_global_rules.should_skip_vertical_adjustment(glyph_file) or
                    self.metric_size_rules.should_skip_vertical_adjustment(width_mode, glyph_file)
            ):
                vertical_offset_y -= 1

            builder.glyphs.append(Glyph(
                name=glyph_file.glyph_name,
                advance_width=advance_width,
                advance_height=advance_height,
                mono_raster=MonoRaster(
                    horizontal_offset=(horizontal_offset_x, horizontal_offset_y),
                    vertical_offset=(vertical_offset_x, vertical_offset_y),
                    bitmap=glyph_file.suggest_bitmap(),
                ),
            ))

        character_mapping = self.cmap_contexts[width_mode].get_character_mapping(language_flavor)
        builder.character_mapping.update(character_mapping)

        if width_mode == 'proportional':
            kerning_values = self.kerning_template.calculate_kerning_values(self.cmap_contexts['proportional'], language_flavor)
            builder.kerning_values.update(kerning_values)

        builder.opentype_config.field_overrides.head_y_max = layout_metric.ascent
        builder.opentype_config.field_overrides.head_y_min = layout_metric.descent

        feature_sources = [
            opentype.FeatureFile(
                paths.CONFIGS_FEATURES_DIR.joinpath('calt.fea'),
                include_dir=paths.CONFIGS_FEATURES_DIR,
            ),
            opentype.FeatureFile(
                paths.CONFIGS_FEATURES_DIR.joinpath('ccmp.fea'),
                include_dir=paths.CONFIGS_FEATURES_DIR,
            ),
        ]
        if self.font_size != 8:
            feature_sources.extend([
                opentype.FeatureFile(
                    paths.CONFIGS_FEATURES_DIR.joinpath('vert.fea'),
                    include_dir=paths.CONFIGS_FEATURES_DIR,
                ),
                opentype.FeatureFile(
                    paths.CONFIGS_FEATURES_DIR.joinpath(f'vert.{language_flavor}.fea'),
                    include_dir=paths.CONFIGS_FEATURES_DIR,
                ),
            ])
        builder.opentype_config.features = opentype.FeatureProgram(feature_sources)

        return builder

    def make_fonts(self, width_mode: WidthMode, font_formats: Sequence[FontFormat]) -> None:
        paths.OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)

        if font_formats:
            for language_flavor in options.LANGUAGE_FLAVORS:
                builder = self.create_builder(width_mode, language_flavor)
                for font_format in font_formats:
                    file_path = paths.OUTPUTS_DIR.joinpath(f'{project.FILE_NAME_PREFIX}-{self.font_size}px-{width_mode}-{language_flavor}.{font_format}')
                    getattr(builder, f'save_{font_format.replace('.', '_').replace('-', '_')}')(file_path)
                    logger.info('Make font: {!r}', str(file_path))
