from collections.abc import Sequence
from zipfile import ZipFile

from loguru import logger

from tools.config import paths, project, manifest, options
from tools.config.options import FontSize, WidthMode, FontFormat


def make_release_zips(font_size: FontSize, width_mode: WidthMode, font_formats: Sequence[FontFormat]) -> None:
    paths.RELEASES_DIR.mkdir(parents=True, exist_ok=True)

    for font_format in font_formats:
        zip_file_path = paths.RELEASES_DIR.joinpath(f'{project.FILE_NAME_PREFIX}-font-{font_size}px-{width_mode}-{font_format.replace('-', '_')}-v{project.VERSION}.zip')
        with ZipFile(zip_file_path, 'w') as file:
            file.write(paths.PROJECT_ROOT_DIR.joinpath('LICENSE-OFL'), 'OFL.txt')

            for font_name, file_names in sorted(manifest.LICENSE_CONFIGS[font_size].items()):
                for file_name in file_names:
                    file.write(paths.FONTS_DIR.joinpath(font_name, file_name), f'LICENSES/{font_name}/{file_name}')

            for language_flavor in options.LANGUAGE_FLAVORS:
                font_file_path = paths.OUTPUTS_DIR.joinpath(f'{project.FILE_NAME_PREFIX}-{font_size}px-{width_mode}-{language_flavor}.{font_format}')
                file.write(font_file_path, font_file_path.name)
        logger.info('Make release zip: {!r}', str(zip_file_path))


def update_docs() -> None:
    paths.DOCS_DIR.mkdir(parents=True, exist_ok=True)

    for path_from in sorted((
            *paths.OUTPUTS_DIR.glob('info-*px-*.md'),
            *paths.OUTPUTS_DIR.glob('preview-*px.png'),
    )):
        if not path_from.is_file():
            continue

        path_to = path_from.copy_into(paths.DOCS_DIR)
        logger.info('Copy file: {!r} -> {!r}', str(path_from), str(path_to))
