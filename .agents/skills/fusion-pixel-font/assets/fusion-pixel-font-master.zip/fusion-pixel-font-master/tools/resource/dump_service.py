import math
from collections.abc import Sequence

import unidata_blocks
from PIL import ImageFont, Image, ImageDraw
from fontTools.ttLib import TTFont
from loguru import logger
from pixel_font_knife.bitmap.mono import MonoBitmap
from pixel_font_knife.cmap.file import CmapGlyphFile

from tools.config import paths, options
from tools.config.dump import DumpConfig
from tools.config.fallback import FallbackConfig
from tools.config.font import FontConfig
from tools.config.options import FontSize


def dump_fonts(font_size: FontSize, dump_configs: Sequence[DumpConfig]) -> None:
    for dump_config in dump_configs:
        dump_dir = paths.DUMP_DIR.joinpath(str(font_size), dump_config.dump_dir_name)
        logger.info('Dump glyphs: {!r}', str(dump_dir))

        font = TTFont(dump_config.font_file_path)
        image_font = ImageFont.truetype(dump_config.font_file_path, dump_config.rasterize_size)

        canvas_height = math.ceil((font['hhea'].ascent - font['hhea'].descent) / font['head'].unitsPerEm * dump_config.rasterize_size)
        if (canvas_height - font_size) % 2 != 0:
            canvas_height += 1

        for code_point, glyph_name in font.getBestCmap().items():
            c = chr(code_point)
            block = unidata_blocks.get_block_by_code_point(code_point)
            if not c.isprintable() and block != unidata_blocks.BLOCK_PRIVATE_USE_AREA:
                continue

            canvas_width = math.ceil(font['hmtx'].metrics[glyph_name][0] / font['head'].unitsPerEm * dump_config.rasterize_size)
            if canvas_width <= 0:
                continue
            elif canvas_width > font_size and block != unidata_blocks.BLOCK_PRIVATE_USE_AREA:
                canvas_width = font_size

            image = Image.new('RGBA', (canvas_width, canvas_height), (0, 0, 0, 0))
            ImageDraw.Draw(image).text(dump_config.rasterize_offset, c, fill=(0, 0, 0, 255), font=image_font)

            glyph_file_dir = CmapGlyphFile.get_normalized_dir(code_point, dump_dir)
            glyph_file_dir.mkdir(parents=True, exist_ok=True)
            glyph_file_path = glyph_file_dir.joinpath(f'{code_point:04X}.png')
            image.save(glyph_file_path)


def apply_fallbacks(font_config: FontConfig, fallback_configs: Sequence[FallbackConfig]) -> None:
    font_size = font_config.font_size

    contexts = {}
    for fallback_config in fallback_configs:
        dir_from = paths.DUMP_DIR.joinpath(str(font_size), fallback_config.dir_from)
        assert dir_from.is_dir(), f'dump dir not exist: {str(dir_from)!r}'
        logger.info("Fallback glyphs: '{}' '{}' {!r}", fallback_config.glyph_scope, fallback_config.flavors, str(dir_from))

        if fallback_config.glyph_scope in contexts:
            context = contexts[fallback_config.glyph_scope]
        else:
            context = {}
            contexts[fallback_config.glyph_scope] = context

        if fallback_config.glyph_scope == 'proportional':
            canvas_height = font_config.canvas_height
        else:
            canvas_height = font_size

        for file_path in dir_from.rglob('*.png'):
            if not file_path.is_file():
                continue

            bitmap = MonoBitmap.load_png(file_path)
            if bitmap.height > canvas_height:
                padding = min((bitmap.height - canvas_height) // 2, bitmap.measure_top_padding(), bitmap.measure_bottom_padding())
                if padding != 0:
                    bitmap = bitmap.resize(top=-padding, bottom=-padding)
            elif bitmap.height < canvas_height:
                padding = (canvas_height - bitmap.height) // 2
                bitmap = bitmap.resize(top=padding, bottom=padding)

            code_point = int(file_path.stem, 16)
            if code_point in context:
                bitmap_strings = context[code_point]
            else:
                bitmap_strings = {}
                context[code_point] = bitmap_strings

            bitmap_string = str(bitmap)
            if bitmap_string in bitmap_strings:
                _, flavors = bitmap_strings[bitmap_string]
            else:
                flavors = set()
                bitmap_strings[bitmap_string] = bitmap, flavors

            if fallback_config.flavors is not None:
                flavors.update(fallback_config.flavors)

    for glyph_scope, context in contexts.items():
        glyph_scope_dir = paths.FALLBACK_GLYPHS_DIR.joinpath(str(font_size), 'cmap', glyph_scope)
        for code_point, bitmap_strings in context.items():
            file_dir = CmapGlyphFile.get_normalized_dir(code_point, glyph_scope_dir)
            file_dir.mkdir(parents=True, exist_ok=True)

            for bitmap, flavors in bitmap_strings.values():
                if flavors:
                    flavors = sorted(flavors, key=lambda x: options.LANGUAGE_FLAVORS.index(x))
                    file_name = f'{code_point:04X} {",".join(flavors)}.png'
                else:
                    file_name = f'{code_point:04X}.png'

                file_path = file_dir.joinpath(file_name)
                bitmap.save_png(file_path)
        logger.info("Fallback context: {} '{}'", font_size, glyph_scope)
