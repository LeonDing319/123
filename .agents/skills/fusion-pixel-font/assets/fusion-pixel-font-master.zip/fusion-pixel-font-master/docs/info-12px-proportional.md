# Fusion Pixel 12px 比例模式

## 基本信息

| 属性 | 值 |
|---|---|
| 版本号 | 2026.11.10 |
| 字符总数 | 38213 |

## Unicode 字符统计

Unicode 版本：18.0.0

| 区块范围 | 区块名称 | 区块含义 | 完成数 | 缺失数 | 进度 |
|---|---|---|---:|---:|---:|
| 0000 ~ 007F | Basic Latin | 基本拉丁字母 | 95 / 95 | 0 | 100.00% 🚩 |
| 0080 ~ 00FF | Latin-1 Supplement | 拉丁字母增补-1 | 95 / 95 | 0 | 100.00% 🚩 |
| 0100 ~ 017F | Latin Extended-A | 拉丁字母扩充-A | 128 / 128 | 0 | 100.00% 🚩 |
| 0180 ~ 024F | Latin Extended-B | 拉丁字母扩充-B | 127 / 208 | 81 | 61.06% 🚧 |
| 0370 ~ 03FF | Greek and Coptic | 希腊字母与科普特字母 | 99 / 135 | 36 | 73.33% 🚧 |
| 0400 ~ 04FF | Cyrillic | 西里尔字母 | 153 / 256 | 103 | 59.77% 🚧 |
| 1E00 ~ 1EFF | Latin Extended Additional | 拉丁字母扩充附加 | 256 / 256 | 0 | 100.00% 🚩 |
| 2000 ~ 206F | General Punctuation | 通用标点 | 39 / 84 | 45 | 46.43% 🚧 |
| 2070 ~ 209F | Superscripts and Subscripts | 上标与下标 | 42 / 46 | 4 | 91.30% 🚧 |
| 2100 ~ 214F | Letterlike Symbols | 字母式符号 | 9 / 80 | 71 | 11.25% 🚧 |
| 2150 ~ 218F | Number Forms | 数字形式 | 60 / 60 | 0 | 100.00% 🚩 |
| 2190 ~ 21FF | Arrows | 箭头 | 112 / 112 | 0 | 100.00% 🚩 |
| 2300 ~ 23FF | Miscellaneous Technical | 杂项技术符号 | 46 / 256 | 210 | 17.97% 🚧 |
| 2460 ~ 24FF | Enclosed Alphanumerics | 包围字母数字 | 160 / 160 | 0 | 100.00% 🚩 |
| 2500 ~ 257F | Box Drawing | 方框绘制字符 | 128 / 128 | 0 | 100.00% 🚩 |
| 2580 ~ 259F | Block Elements | 方块元素 | 32 / 32 | 0 | 100.00% 🚩 |
| 25A0 ~ 25FF | Geometric Shapes | 几何形状 | 96 / 96 | 0 | 100.00% 🚩 |
| 2600 ~ 26FF | Miscellaneous Symbols | 杂项符号 | 188 / 256 | 68 | 73.44% 🚧 |
| 2700 ~ 27BF | Dingbats | 装饰符号 | 34 / 192 | 158 | 17.71% 🚧 |
| 2800 ~ 28FF | Braille Patterns | 盲文图案 | 256 / 256 | 0 | 100.00% 🚩 |
| 2C60 ~ 2C7F | Latin Extended-C | 拉丁字母扩充-C | 4 / 32 | 28 | 12.50% 🚧 |
| 2E80 ~ 2EFF | CJK Radicals Supplement | 中日韩部首增补 | 115 / 115 | 0 | 100.00% 🚩 |
| 2F00 ~ 2FDF | Kangxi Radicals | 康熙部首 | 214 / 214 | 0 | 100.00% 🚩 |
| 2FF0 ~ 2FFF | Ideographic Description Characters | 表意文字描述字符 | 16 / 16 | 0 | 100.00% 🚩 |
| 3000 ~ 303F | CJK Symbols and Punctuation | 中日韩符号与标点 | 64 / 64 | 0 | 100.00% 🚩 |
| 3040 ~ 309F | Hiragana | 平假名 | 93 / 93 | 0 | 100.00% 🚩 |
| 30A0 ~ 30FF | Katakana | 片假名 | 96 / 96 | 0 | 100.00% 🚩 |
| 3100 ~ 312F | Bopomofo | 注音字母 | 43 / 43 | 0 | 100.00% 🚩 |
| 3130 ~ 318F | Hangul Compatibility Jamo | 谚文兼容字母 | 94 / 94 | 0 | 100.00% 🚩 |
| 3200 ~ 32FF | Enclosed CJK Letters and Months | 包围中日韩字母与月份 | 92 / 255 | 163 | 36.08% 🚧 |
| 3300 ~ 33FF | CJK Compatibility | 中日韩兼容 | 60 / 256 | 196 | 23.44% 🚧 |
| 3400 ~ 4DBF | CJK Unified Ideographs Extension A | 中日韩统一表意文字扩充 A | 1777 / 6592 | 4815 | 26.96% 🚧 |
| 4E00 ~ 9FFF | CJK Unified Ideographs | 中日韩统一表意文字 | 19546 / 20992 | 1446 | 93.11% 🚧 |
| A720 ~ A7FF | Latin Extended-D | 拉丁字母扩充-D | 7 / 206 | 199 | 3.40% 🚧 |
| AC00 ~ D7AF | Hangul Syllables | 谚文音节 | 11172 / 11172 | 0 | 100.00% 🚩 |
| E000 ~ F8FF | Private Use Area | 私用区域 | 252 / 0 | 0 | 100.00% 🚩 |
| F900 ~ FAFF | CJK Compatibility Ideographs | 中日韩兼容表意文字 | 436 / 472 | 36 | 92.37% 🚧 |
| FE10 ~ FE1F | Vertical Forms | 竖排形式 | 10 / 10 | 0 | 100.00% 🚩 |
| FE30 ~ FE4F | CJK Compatibility Forms | 中日韩兼容形式 | 32 / 32 | 0 | 100.00% 🚩 |
| FF00 ~ FFEF | Halfwidth and Fullwidth Forms | 半宽与全宽形式 | 173 / 225 | 52 | 76.89% 🚧 |
| FFF0 ~ FFFF | Specials | 特殊字符 | 2 / 2 | 0 | 100.00% 🚩 |
| 16FE0 ~ 16FFF | Ideographic Symbols and Punctuation | 表意文字符号与标点 | 5 / 12 | 7 | 41.67% 🚧 |
| 1F100 ~ 1F1FF | Enclosed Alphanumeric Supplement | 包围字母数字增补 | 145 / 201 | 56 | 72.14% 🚧 |
| 1FA00 ~ 1FA6F | Chess Symbols | 棋类符号 | 36 / 102 | 66 | 35.29% 🚧 |
| 20000 ~ 2A6DF | CJK Unified Ideographs Extension B | 中日韩统一表意文字扩充 B | 1458 / 42720 | 41262 | 3.41% 🚧 |
| 2A700 ~ 2B73F | CJK Unified Ideographs Extension C | 中日韩统一表意文字扩充 C | 38 / 4160 | 4122 | 0.91% 🚧 |
| 2B740 ~ 2B81F | CJK Unified Ideographs Extension D | 中日韩统一表意文字扩充 D | 11 / 223 | 212 | 4.93% 🚧 |
| 2B820 ~ 2CEAF | CJK Unified Ideographs Extension E | 中日韩统一表意文字扩充 E | 48 / 5774 | 5726 | 0.83% 🚧 |
| 2CEB0 ~ 2EBEF | CJK Unified Ideographs Extension F | 中日韩统一表意文字扩充 F | 8 / 7473 | 7465 | 0.11% 🚧 |
| 30000 ~ 3134F | CJK Unified Ideographs Extension G | 中日韩统一表意文字扩充 G | 11 / 4939 | 4928 | 0.22% 🚧 |

## GB2312 字符统计

简体中文参考字符集。统计范围不包含 ASCII。

| 区块名称 | 完成数 | 缺失数 | 进度 |
|---|---:|---:|---:|
| 一级汉字 | 3755 / 3755 | 0 | 100.00% 🚩 |
| 二级汉字 | 2972 / 3008 | 36 | 98.80% 🚧 |
| 其他字符 | 651 / 682 | 31 | 95.45% 🚧 |
| 总计 | 7378 / 7445 | 67 | 99.10% 🚧 |

## Big5 字符统计

繁体中文参考字符集。统计范围不包含 ASCII。

| 区块名称 | 完成数 | 缺失数 | 进度 |
|---|---:|---:|---:|
| 常用汉字 | 5401 / 5401 | 0 | 100.00% 🚩 |
| 次常用汉字 | 6847 / 7652 | 805 | 89.48% 🚧 |
| 其他字符 | 345 / 408 | 63 | 84.56% 🚧 |
| 总计 | 12593 / 13461 | 868 | 93.55% 🚧 |

## Shift-JIS 字符统计

日语参考字符集。

| 区块名称 | 完成数 | 缺失数 | 进度 |
|---|---:|---:|---:|
| 单字节-ASCII可打印字符 | 95 / 95 | 0 | 100.00% 🚩 |
| 单字节-半角片假名 | 63 / 63 | 0 | 100.00% 🚩 |
| 双字节-其他字符 | 492 / 524 | 32 | 93.89% 🚧 |
| 双字节-汉字 | 6355 / 6355 | 0 | 100.00% 🚩 |
| 总计 | 7005 / 7037 | 32 | 99.55% 🚧 |

## KS-X-1001 字符统计

韩语参考字符集。统计范围不包含 ASCII。

| 区块名称 | 完成数 | 缺失数 | 进度 |
|---|---:|---:|---:|
| 谚文音节 | 2350 / 2350 | 0 | 100.00% 🚩 |
| 汉字 | 4858 / 4888 | 30 | 99.39% 🚧 |
| 其他字符 | 803 / 988 | 185 | 81.28% 🚧 |
| 总计 | 8011 / 8226 | 215 | 97.39% 🚧 |
